public class Manager extends Company implements Employee{
    private double managerSalary = 0;
    private final int salaryToPay;

    public Manager(int salaryToPay){
        this.salaryToPay = salaryToPay;
    }

    public int getMonthSalary() {
        int randomNum = (int)(Math.random() * 25000) + 115000;
        managerSalary +=  (salaryToPay + ( randomNum / 100 * 5));
        totalMoney += managerSalary;
        return (int) managerSalary;
    }

    @Override
    public String toString() {
        return
                "Зараплата менеджера: " + managerSalary + "\t"
                 ;
    }
}
