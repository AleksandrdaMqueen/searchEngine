import java.util.ArrayList;

public class Main   {
    public static void main(String[] args) {
        Company company = new Company();
        int totalMoney = 0;





        for (int i = 0; i != 80; i++) { // найм 80 менеджеров
            int randomNum = (int)(Math.random() * 25000) + 115000;
            company.hire(new Manager(60000 + randomNum / 100 * 5));
            totalMoney += Manager.salary;
        }

        for (int k = 0; k != 10; k++) { //найм 10 топ-менеджеров

                company.hire(new TopManager(60000 + (60000 * 1.5)));

        }


        for (int a = 0; a != 180; a++) { // найм 180 операторов
            company.hire(new Operator((int)(Math.random() * 20000) + 60000));
        }



        System.out.println("Кол-во сотрудников в компании: " + company.size());
        System.out.println("Самые низкие зарплаты в компании: " + company.getLowestSalaryStaff(30));
        System.out.println("Самые высокие зарплаты в компании: " + company.getHighestSalaryStaff(10));
        for (int i = 0; i < company.size() ; i++) { // удаление 50% сотрудниклов
            company.fire(i);
        }

        System.out.println("Кол-во сотрудников в компании: " + company.size());
        System.out.println("Самые низкие зарплаты в компании: " + company.getLowestSalaryStaff(30));
        System.out.println("Самые высокие зарплаты в компании: " + company.getHighestSalaryStaff(10));







    }
}
