

public class Main {
    public static void main(String[] args) {




        Manager manager = new Manager(100000);
        Operator operator = new Operator(60000);
        TopManager topManager = new TopManager(150000);

        System.out.println("Зарплата менеджера: " + manager.getMonthSalary());
        System.out.println("Зарплата оператора: " + operator.getMonthSalary());
        System.out.println("Зарплата топ-менеджера " + topManager.getMonthSalary());

    }
}
