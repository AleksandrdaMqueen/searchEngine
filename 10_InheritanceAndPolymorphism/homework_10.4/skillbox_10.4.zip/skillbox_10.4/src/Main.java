import java.util.ArrayList;

public class Main   {
    public static void main(String[] args) {
        Company company = new Company();
        ArrayList<Employee> allEmployee= new ArrayList<>();
        int totalMoney = 0;





        for (int i = 0; i <= 80; i++) {
            int randomNum = (int)(Math.random() * 25000) + 115000;
            company.hire(new Manager(60000 + randomNum / 100 * 5));
        }

        for (int k = 0; k <= 10; k++) {
            if (totalMoney < 10000000) {
                company.hire(new TopManager(60000 + 60000 * 1.5));
            }else{
                company.hire(new TopManager(60000 + 60000 * 1.5));
            }
        }

        for (int a = 0; a < 80; a++) {
            company.hire(new Operator(60000));
        }





    }
}
