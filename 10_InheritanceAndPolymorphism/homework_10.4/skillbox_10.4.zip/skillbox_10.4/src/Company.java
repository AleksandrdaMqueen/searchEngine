import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Company {
    public  int totalMoney = 0;

    ArrayList<Employee> employees = new ArrayList<>();


    public void hire(Employee employee){
        employees.add(employee);
    }

    public void hireAll(ArrayList<Employee> employeesToAdd){
        employees.add((Employee) employeesToAdd);
    }

    public void fire(String employee){
        employees.remove(employee);
    }

    public  int getIncome(){
        for (int i = 0; i < employees.size(); i++) {
            if(employees.get(i) instanceof Manager){
                int randomNum = (int)(Math.random() * 25000) + 115000;
            }
        }
        return totalMoney;
    }

    List<Employee> getTopSalaryStaff(int count){
        employees.sort(Comparator.comparing(Employee::getMonthSalary));
        return employees.subList(count, 0 );
    }

    public  List<Employee> getLowestSalaryStaff(int count){
        employees.sort(Comparator.comparing(Employee::getMonthSalary));
        return employees.subList(0, count);
    }



}
