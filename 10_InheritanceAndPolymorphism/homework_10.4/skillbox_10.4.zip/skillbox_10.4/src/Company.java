import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Company {
    public  int totalMoney = 0;

    ArrayList<String> employees = new ArrayList<>();


    public void hire(String employee){
        employees.add(employee);
    }

    public void hireAll(ArrayList<String> employeesToAdd){
        employees.add(String.valueOf(employeesToAdd));
    }

    public void fire(String employee){
        employees.remove(employee);
    }

    public  int getIncome(){
        return totalMoney;
    }

    List<Employee> getTopSalaryStaff(int count){
        List list = new ArrayList(Collections.singleton(new Comparator<Employee>() {

            @Override
            public int compare(Employee o1, Employee o2) {
                if (o1.getMonthSalary() > o2.getMonthSalary()) {
                    return 1;
                }
                if (o1.getMonthSalary() < o2.getMonthSalary()) {
                    return -1;
                }
                return 0;
            }
        }));
        return list;
    }

    List<Employee> getLowestSalaryStaff(int count){
        List list = new ArrayList(Collections.singleton(new Comparator<Employee>() {

            @Override
            public int compare(Employee o1, Employee o2) {
                if (o1.getMonthSalary() > o2.getMonthSalary()) {
                    return -1;
                }
                if (o1.getMonthSalary() < o2.getMonthSalary()) {
                    return 1;
                }
                return 0;
            }
        }));
        return list;
    }



}
