public class Operator extends Company implements Employee{
    private final int salaryToPay;
    int operatorSalary = 0;

    public Operator(int salaryToPay){
        this.salaryToPay = salaryToPay;
    }


    @Override
    public int getMonthSalary() {
        operatorSalary = salaryToPay;
        totalMoney += operatorSalary;
        return operatorSalary;
    }

    @Override
    public String toString() {
        return
                "Зарплата опереатора: " + operatorSalary
                ;
    }
}
