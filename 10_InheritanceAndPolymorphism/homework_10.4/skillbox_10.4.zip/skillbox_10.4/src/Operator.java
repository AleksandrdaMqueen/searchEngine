public class Operator extends Company implements Employee{
    private final int salaryToPay;

    public Operator(int salaryToPay){
        this.salaryToPay = salaryToPay;
    }


    @Override
    public int getMonthSalary() {
        int operatorSalary = salaryToPay;
        totalMoney += operatorSalary;
        return operatorSalary;
    }
}
