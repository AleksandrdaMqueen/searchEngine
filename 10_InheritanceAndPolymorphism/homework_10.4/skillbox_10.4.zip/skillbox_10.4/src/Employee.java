public interface Employee {
    int salary = 0;
    public int getMonthSalary();
}
