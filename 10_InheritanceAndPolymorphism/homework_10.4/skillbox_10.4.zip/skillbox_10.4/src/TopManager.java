public class TopManager extends Company implements Employee  {
    private int topManagerSalary = 0;
    private int salaryToPay;

    public TopManager(int salaryToPay){
        this.salaryToPay = salaryToPay;


    }


    @Override
    public int getMonthSalary() {
        if(totalMoney > 1000000){
            topManagerSalary += salaryToPay + (salaryToPay / 100 * 50);
        }else {
            topManagerSalary += salaryToPay;
        }
        totalMoney += topManagerSalary;
        return topManagerSalary;
    }
}
