public class TopManager extends Company implements Employee  {
    private int topManagerSalary = 0;
    private double salaryToPay;

    public TopManager(double salaryToPay){
        this.salaryToPay = salaryToPay;


    }




    @Override
    public int getMonthSalary() {
        if(totalMoney > 1000000){
            topManagerSalary += salaryToPay + (salaryToPay / 100 * 50);
        }else {
            topManagerSalary += salaryToPay;
        }
        totalMoney += topManagerSalary;
        return topManagerSalary;
    }

    @Override
    public String toString() {
        return
                "Зарплата топ-менеджера: " + topManagerSalary
                ;
    }
}
